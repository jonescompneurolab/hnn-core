"""
===================
Plot firing pattern
===================

This example demonstrates how to inspect the firing
pattern of cells in the HNN model.
"""

# Authors: Mainak Jas <mjas@harvard.mgh.edu>

import os.path as op

###############################################################################
# Let us import hnn_core

import hnn_core
from hnn_core import read_params, Network, simulate_dipole

hnn_core_root = op.dirname(hnn_core.__file__)

###############################################################################
# Then we read the parameters file
params_fname = op.join(hnn_core_root, 'param', 'default.json')
params = read_params(params_fname)

###############################################################################
# Now let's build the network with somatic voltage recordings enabled
import matplotlib.pyplot as plt

net = Network(params)
dpls = simulate_dipole(net, n_trials=1, record_vsoma=True)

###############################################################################
# The cell IDs (gids) are stored in the network object as a dictionary
gid_dict = net.gid_dict
print(net.gid_dict)

###############################################################################
# Simulated cell responses are stored in the Spikes object as a dictionary.
trial_idx = 0
vsoma = net.spikes.vsoma[trial_idx]
print(vsoma.keys())

###############################################################################
# We can plot the firing pattern of individual cells by indexing with the gid
gid = 170
times = net.spikes.times[trial_idx]
plt.figure(figsize=(4, 4))
plt.plot(times, vsoma[gid])
plt.title('%s (gid=%d)' % (net.gid_to_type(gid), gid))
plt.xlabel('Time (ms)')
plt.ylabel('Voltage (mV)')
plt.show()

###############################################################################
# Let's do this for the rest of the cell types
fig, axes = plt.subplots(1, 2, sharey=True, figsize=(8, 4))
for gid, ax in zip([gid_dict['L2_pyramidal'][0],
                    gid_dict['L5_pyramidal'][0]], axes):
    ax.plot(times, vsoma[gid])
    ax.set_title('%s (gid=%d)' % (net.gid_to_type(gid), gid))
    ax.set_xlabel('Time (ms)')
    ax.set_ylabel('Voltage (mV)')
plt.show()

###############################################################################
# The spiking activity across cell types can also be visualized with raster
# plots and histograms

# Spike raster plot
net.spikes.plot()

# Spike histogram
fig, axes = plt.subplots(1, 1, figsize=(8, 4))
net.spikes.plot_hist(ax=axes, spike_types=['L2_pyramidal', 'L5_pyramidal'])
axes.set_xlabel('Time (ms)')
